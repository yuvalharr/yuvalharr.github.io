## R Package Version

R version 3.5.3

lmerTest 3.1-0 

lme4 1.1-21

Matrix 1.2-15  

GGally 1.4.0   

ggplot2 3.1.1 

tidyr 0.8.3    

psych 1.8.12   

readr 1.3.1 

