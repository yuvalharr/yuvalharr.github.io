## Instruction

`virtual_chinrest.js` contains a simple JavaScript plugin that you can use to estimate for pariticipants' viewing distances in online experiments.

Open `example.html` in a web browser to see an example.

Configuration data are stored in variable `data` which you can inspect via the console.
